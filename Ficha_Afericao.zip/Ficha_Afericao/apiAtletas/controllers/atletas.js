var Atletas = require('../models/atletas');

module.exports.list = () => {
    return Atletas
        .find()
        .sort({nome: 1})
        .exec()

}