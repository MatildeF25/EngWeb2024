var express = require('express');
var router = express.Router();
var atletas = require('../controllers/atletas')

/* GET home page. */
router.get('/pessoas', function(req, res, next) {
  atletas.list()
    .then(dados => res.jsonp(dados))
    .catch(erro => res.status(500).jsonp(erro))
});

module.exports = router;
